package com.ldifbatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdifBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdifBatchApplication.class, args);
	}

}
