package com.ldifbatch.constants;

public class Constants {
	public static final Integer toReadAtATime = 2;
	public static final String ldifFilePath = "classpath:oudAccountsExport.ldif";
}
