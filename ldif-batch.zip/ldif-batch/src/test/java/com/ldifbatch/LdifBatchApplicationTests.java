package com.ldifbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdifBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
