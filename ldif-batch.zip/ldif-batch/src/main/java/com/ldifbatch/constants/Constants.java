package com.ldifbatch.constants;

public class Constants {
	public static final Integer toReadAtATime =3+1;
	public static final String ldifFilePath = "classpath:oudAccountsExport.ldif";
}
